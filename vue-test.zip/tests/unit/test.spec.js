import { mount } from '@vue/test-utils'

import Articles from "../../src/components/Articles";

describe('Articles', () => {
  // Now mount the component and you have the wrapper
  const wrapper = mount(Articles);

  // it's also easy to check for the existence of elements
  it('has posts', () => {
    setTimeout(function () {
      expect(wrapper.contains('Article')).toBe(true);

      expect(wrapper.contains('.article')).toBe(true);

      expect(wrapper.contains('.comments')).toBe(true);

      expect(wrapper.vm.posts).toBe( [
        {
          "id": 1,
          "title": "Post 1",
          "image": "1.jpg",
          "price": "12.90",
          "liked": 999,
          "Ilked": true,
          "author": {
            "name": "Gabriel",
            "image": "man.jpg"
          },
          "comments": [
            "dwdw",
            "2121",
            "212"
          ]
        },
        {
          "id": 2,
          "title": "Post 2",
          "image": "2.jpg",
          "price": "9.72",
          "liked": 2,
          "Ilked": true,
          "author": {
            "name": "Zara",
            "image": "woman.jpg"
          },
          "comments": [
            "e2323"
          ]
        },
        {
          "id": 3,
          "title": "Post 3",
          "image": "3.jpg",
          "price": "7.15",
          "liked": 1,
          "Ilked": true,
          "author": {
            "name": "Zara",
            "image": "woman.jpg"
          },
          "comments": []
        }
      ])

    },2000)

  })




})