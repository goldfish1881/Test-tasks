<template>
  <div id="app">
    <Articles/>
  </div>
</template>

<script>
import Articles from './components/Articles'

export default {
  name: 'app',
  components: {
    Articles
  }
}
</script>

<style>
 #app{
   font-family: 'Roboto', sans-serif;
 }
</style>
