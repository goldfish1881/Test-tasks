<template>
  <div class="comment">
    <p>{{comment}}</p>
  </div>
</template>

<script>

export default {
  name: 'Comment',
  props: ['comment'],
  mounted() {

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
 .comment {
    p {
      margin: 10px 5px;
      background: white;
      font-size: 13px;
      border-radius: 4px;
      padding: 5px;
    }
 }
</style>
