<template>
  <div class="articles-wrapper" v-if="posts.length">
    <Article v-for="post in posts" :key="post.id" :post="post"></Article>
  </div>
</template>

<script>
import Article from "./Article";
import axios from 'axios'

export default {
  name: 'Articles',
  components: {Article},
  props: {

  },
  data() {
    return {
      posts: []
    }
  },
  mounted() {
    axios
            .get('http://localhost:3000/posts')
            .then(response => {
              this.posts = response.data;
            })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
 .articles-wrapper {
   width: 250px;
   background: whitesmoke;
   display: flex;
   justify-content: center;
   padding: 5px;
   flex-direction: column;
   align-items: center;
   margin: 0 auto;
 }
</style>
