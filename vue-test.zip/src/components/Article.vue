    <template>
      <div class="article" v-if="post">
        <div class="header">
            <img :src="require(`../assets/img/${post.author.image}`)" alt="">
            <h4>{{post.author.name}}</h4>
        </div>
        <div class="z-depth-1">
            <div class="post-wrapper" :style="{backgroundImage:`url(${require(`../assets/img/post/${post.image}`)})`}">
                <h3>{{post.title}}</h3>
            </div>
            <div class="footer">
                <div>
                    <span>€{{post.price}}</span>
                </div>
                <div>
                   <span class="icon-wrapper"  @click="showComment()">
                        <vue-fontawesome icon="comment" size="1.3" color="silver" style="margin-right: 5px" class="footer-icon"></vue-fontawesome>
                       <span :title="post.comments.length" class="icon-count" v-if="post.comments.length">{{post.comments.length}}</span>
                   </span>
                    <span class="icon-wrapper" @click="likePost()">
                       <vue-fontawesome icon="heart" size="1.3" :class="{ active: !!post.Ilked }" color="silver" class="footer-icon"></vue-fontawesome>
                       <span :title="post.liked" class="icon-count" v-if="post.liked">{{post.liked}}</span>
                   </span>
                </div>
            </div>
            <div class="comments" v-if="this.showComments">
                <div v-if="this.post.comments.length">
                    <Comment :key="index" v-for="(comment, index) in this.post.comments" :comment="comment"></Comment>
                </div>
                <form @submit="addComment" >
                    <input v-model="comment" placeholder="add comment...">
                    <button>
                        <vue-fontawesome size="1.1"  color="silver" icon="paper-plane"></vue-fontawesome>
                    </button>
                </form>
            </div>
        </div>
      </div>
    </template>

  <script>
    import Comment from "./Comment";
    import axios from 'axios'
    export default {
      name: 'Article',
        components: {Comment},
        props: ['post'],
      data() {
            return {
                showComments: false,
                comment: '',
            }
      },
      mounted() {

      },
      methods: {

         likePost() {
             if (this.post.Ilked) {
                 this.post.Ilked = false;
                 this.post.liked -= 1;
             } else {
                 this.post.Ilked = true;
                 this.post.liked += 1;
             }
            this.updatePost();
         },

          showComment() {
              this.showComments = !this.showComments;
          },

          addComment(e) {
              if(this.comment.length) {
               this.post.comments.push(this.comment);
               this.comment = '';
               this.updatePost();
              }
              e.preventDefault();
          },
          updatePost() {
              axios
                  .put(`http://localhost:3000/posts/${this.post.id}`, this.post)
                  .then(response => {
                      // eslint-disable-next-line no-console
                      console.log(response.data);
                  })
          }
      }
    }
  </script>

    <!-- Add "scoped" attribute to limit CSS to this component only -->
    <style scoped lang="scss">

      .article{
        width: 200px;
        margin-bottom: 10px;

        .header {

                display: flex;
                padding: 5px;
                justify-content: start;
                align-items: center;
                img {
                    height: 30px;
                    border-radius: 50%;
                }

                h4{
                    margin: 0 0 0 8px;
                    font-weight: 400;
                }
            }

        .post-wrapper{
            height: 200px;
            background-position: center;
            background-size: cover;
            background-repeat: no-repeat;
            position: relative;
            -webkit-box-align: end;
            -ms-flex-align: end;
            align-items: flex-end;
            display: flex;
            padding: 0 5px;

            &:before {
                content: '';
                position: absolute;
                height: 100%;
                width: 100%;
                top: 0;
                left: 0;
                background: rgba(239, 239, 239, 0.27);
                z-index: 1;
            }

            h3 {
                position: relative;
                z-index: 2;
                color: #ffffff;
            }
         }

        .footer{
            height: 40px;
            background: white;
            -webkit-box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.3);
            box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.3);
            display: flex;
            justify-content: space-between;
            padding: 0 8px;
            align-items: center;
            font-size: 14px;
            color: #515151;

            .icon-wrapper{
                position: relative;

                .icon-count {
                    position: absolute;
                    font-size: 9px;
                    margin-left: auto;
                    margin-right: auto;
                    left: 0;
                    right: 0;
                    top:  0;
                    text-align: center;
                    white-space: nowrap;
                    width: 13px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    cursor: pointer;
                }

                .footer-icon {
                    cursor: pointer;

                    &.active{
                        color: #f85796 !important;
                    }
                }
            }


        }

        .comments{
            form{
                display: flex;
                align-items: center;
                input {
                    border: none;
                    background: transparent;
                    margin: 10px 8px;
                    border-bottom: 1px solid silver;
                    padding: 5px 0;
                    outline: none;
                    width: 150px;
                }
                button{
                    border: none;
                    outline: none;
                    background: transparent;
                }
            }
        }
      }

      .z-depth-1{
          margin-top: 5px;
          -webkit-box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
          box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
          border-radius: 4px;
          overflow: hidden;
      }
    </style>
